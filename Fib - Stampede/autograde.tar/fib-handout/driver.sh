#!/bin/bash

# driver.sh - The simplest autograder we could think of. It checks
#   that students can write a C program that compiles, and then
#   executes with an exit status of zero.
#   Usage: ./driver.sh

# Compile the code
echo "Compiling fib.c"
(make clean; make)
status=$?
if [ ${status} -ne 0 ]; then
    echo "Failure: Unable to compile fib.c (return status = ${status})"
    echo "{\"scores\": {\"Correctness\": 0}}"
    exit
fi

# Run the code
echo "Running ./fib 20"
output=$(./fib 20)
status=$?

if [ ${status} -ne 0 ]; then
    echo "Failure: ./fib fails or returns nonzero exit status of ${status}"
    echo "{\"scores\": {\"Correctness\": 0}}"
    exit
fi

echo "Output from ./fib 20: $output"

# Check if output matches the expected format: fib(20)=<number>
if echo "$output" | grep -qE '^fib\(20\)=[0-9]+$'; then
    echo "Success: Output matches expected format: $output"
    echo "{\"scores\": {\"Correctness\": 100}}"
else
    echo "Failure: Output does not match expected format 'fib(20)=<number>'"
    echo "  Expected format: fib(20)=<number>"
    echo "  Actual output: $output"
    echo "{\"scores\": {\"Correctness\": 0}}"
fi

exit

